
const columns = 6
const squares = []
let dragElem, dropElem
const colors = [
    'red', 'yellow', 'black', 'blue', 'orange', 'green'
]
document.addEventListener('DOMContentLoaded', () => {
    const grid = document.querySelector('.grid')
    function board() {
        for (let i = 0; i < columns; i++) {
            for (let j = 0; j < columns; j++) {
                const square = document.createElement('div')
                square.setAttribute('draggable', true)
                square.setAttribute('id', `${i}-${j}`)
                let randomColor = generateRandom(0, colors.length - 1)
                square.style.background = colors[randomColor]
                grid.appendChild(square)
                squares.push(square)
            }
        }
    }
    board()
    addListeners()
})
function generateRandom(min, max) {
    return (Math.floor(Math.pow(10, 14) * Math.random() * Math.random()) % (max - min + 1)) + min;
}
function addListeners() {
    squares.forEach(square => {
        square.addEventListener('dragstart', dragStart)
        square.addEventListener('dragover', dragOver)
        square.addEventListener('drop', dragDrop)
    })
}
function dragStart(e) {
    dragElem = this
    console.log(this.style.background)
}
function dragDrop(e) {
    console.log('DROP', this.style.background)
    console.log(e.type)
    dropElem = this
    applyLogic()
}
function dragOver(e) {
    e.preventDefault();
}
function applyLogic() {
    if (validPos()) {
        let color = dragElem.style.background
        dragElem.style.background = dropElem.style.background
        dropElem.style.background = color
        identifySimilarHorizontal()
        identifySimilarVertical()
        // refillEmpty()
    } else {
        dragElem = null
        dropElem = null
    }
}
function validPos() {
    let dragId = parseInt(dragElem.id)
    let dropId = parseInt(dropElem.id)
    return true
    return [dragId + 1, dragId - 1, dragId + columns, dragId - columns].indexOf(dropId) >= 0
}

function identifySimilarHorizontal() {
    for (i = 0; i < columns; i++) {
        for (j = 0; j < columns; j++) {
            //TODO: ADD YOUR SOLUTION HERE
        }
    }
}
function identifySimilarVertical() {
    for (j = 0; j < columns; j++) {
        for (i = 0; i < columns; i++) {
            // TODO: ADD YOUR SOLUTION HERE
        }
    }
}
function refillEmpty() {
    for (i = 0; i < columns; i++) {
        for (j = columns-1; j >=0; j--) {
            let k = j
            let colorElem = document.getElementById(`${j}-${i}`)
            if (colorElem && colorElem.style.background == "") {
                do {
                    let prevElem = document.getElementById(`${k - 1}-${i}`)
                    if (!prevElem) {
                        let randomColor = generateRandom(0, colors.length - 1)
                        colorElem.style.background = colors[randomColor]
                    } else {
                        colorElem.style.background = prevElem.style.background
                        prevElem.style.background = ""
                    }
                    k--;
                } while (colorElem.style.background == "")
            }
        }
    }
}